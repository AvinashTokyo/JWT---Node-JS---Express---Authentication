const express = require('express');
const auth = require('./routes/auth');
const post = require('./routes/post')
const app = express();

//accessing all the routes from auth.js file
app.use(express.json());
app.use('/auth' , auth);
app.use('/post' , post);


app.get("/" , (req , res) => {
    res.send("Hii i am working");
})

// app.post()














app.listen(5000 , () => {
    console.log("Now Running on port 5000!");
})