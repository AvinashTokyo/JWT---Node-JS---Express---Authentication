const router = require("express").Router();
const { check, validationResult } = require("express-validator");
const { users } = require("../db");
//for hashing the password
const bcrypt = require("bcrypt");
//jwt
const JWT = require("jsonwebtoken");

//signup
router.post(
  "/signup",
  [
    check("email", "Please Provide a valid Email - abc@mail.com").isEmail(),
    check("password", "Password must be of length 6").isLength({
      min: 6,
    }),
  ],
  async (req, res) => {
    const { password, email } = req.body;

    //  VALIDATED THE INPUT
    const errors = validationResult(req);

    if (!errors.isEmpty()) {
      return res.status(400).json({
        errors: errors.array(),
      });
    }

    //VALIDATE IF USER DOESN'T ALREADY EXISTS
    let user = users.find((user) => {
      return user.email === email;
    });

    if (user) {
      return res.status(400).json({
        errors: [
          {
            msg: "This user already exists",
          },
        ],
      });
    } else {
      //hashing the password
      const hashedPassword = await bcrypt.hash(password, 10);
      //async call over here
      //hasing the password takes time
      users.push({
        email: email,
        password: hashedPassword,
      });
      console.log(hashedPassword, "hashPass");
    }

    //JWT Token
    const token = await JWT.sign(
      {
        email,
      },
      "asfdhfah345h35hjghfg3454j",
      {
        expiresIn: 3600000,
      }
    );
    res.json({
        token,
      });
    // console.log(password, email);
    // res.send("Auth Route Working");
    // res.send("Validation Passed, Signup Success");
    
  }
);

//login
router.post("/login", async (req, res) => {
  const { password, email } = req.body;

  const user = users.find((user) => {
    return user.email === email;
  });

  if (!user) {
    return res.status(400).json({
      errors: [
        {
          msg: "Invalid Credentials",
        },
      ],
    });
  }

  const isMatched = await bcrypt.compare(password, user.password)

  if (!isMatched) {
    return res.status(400).json({
      errors: [
        {
          msg: "Invalid Credentials",
        },
      ],
    });
  }

  //JWT Token
  const token = await JWT.sign(
    {
      email,
    },
    "asfdhfah345h35hjghfg3454j",
    {
      expiresIn: 3600000,
    }
  );
  res.json({
      token,
    });

});

router.get("/", (req, res) => {
  res.send("Auth Get Router Working");
});

router.get("/all", (req, res) => {
  res.send(users);
});

module.exports = router;
