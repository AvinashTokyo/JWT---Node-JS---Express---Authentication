const users = [
    {
        email: "avi@mail.com",
        password: "123456"
    }
];

const publicPosts = [
    {
    title: "Public Title 1 Here",
    content: "These are some tips 1"
    },
    {
    title: "Public Title 2 Here",
    content: "These are some tips 2"
    },
    {
    title: "Public Title 3 Here",
    content: "These are some tips 3"
    }
]

const privatePosts = [
    {
        title: "Private Title 1 Here",
        content: "These are some tips 1"
    },
    {
        title: "Private Title 2 Here",
        content: "These are some tips 2"
    },
    {
        title: "Private Title 3 Here",
        content: "These are some tips 3"
    }
]

module.exports = {
    users,
    publicPosts,
    privatePosts
}